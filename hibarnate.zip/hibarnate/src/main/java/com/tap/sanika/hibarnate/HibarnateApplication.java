package com.tap.sanika.hibarnate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibarnateApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibarnateApplication.class, args);
	}

}
