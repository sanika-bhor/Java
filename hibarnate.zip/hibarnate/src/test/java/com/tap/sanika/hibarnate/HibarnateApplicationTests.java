package com.tap.sanika.hibarnate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibarnateApplicationTests {

	@Test
	void contextLoads() {
	}

}
